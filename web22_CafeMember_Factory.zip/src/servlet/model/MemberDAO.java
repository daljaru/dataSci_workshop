package servlet.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public interface MemberDAO {
	Connection getConnection() throws SQLException;
	void closeAll(PreparedStatement ps, Connection conn) throws SQLException;
	void closeAll(ResultSet rs, PreparedStatement ps, Connection conn) throws SQLException;
	
	void registerMember(Member vo) throws SQLException;
	ArrayList<Member> showAllMember() throws SQLException;
	Member findMemberById(String id) throws SQLException;
	void updateMember(Member vo) throws SQLException;
	Member login(String tempId, String tempPassword)throws SQLException;

}
