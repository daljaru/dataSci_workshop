package servlet.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class MemberDAOImpl implements MemberDAO{
	private DataSource ds;
	private static MemberDAOImpl dao = new MemberDAOImpl();
	private MemberDAOImpl() {
		try {
			InitialContext ic = new InitialContext();
			ds = (DataSource)ic.lookup("java:comp/env/jdbc/mysql");
			System.out.println("lookup성공");
		} catch (NamingException e1) {
			System.out.println("DataSource Lookup 실패...");
		}
	}
	public static MemberDAOImpl getInstance() {
		return dao;
	}
	
	@Override
	public Connection getConnection() throws SQLException {
		return ds.getConnection();
	}

	@Override
	public void closeAll(PreparedStatement ps, Connection conn) throws SQLException {
		ps.close();
		conn.close();
	}

	@Override
	public void closeAll(ResultSet rs, PreparedStatement ps, Connection conn) throws SQLException {
		rs.close();
		closeAll(ps, conn);
	}

	@Override
	public void registerMember(Member vo) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;		
		try {
			conn = getConnection();
			String query = "INSERT INTO member(id, password, name, address) VALUES(?,?,?,?)";
			ps = conn.prepareStatement(query);
			
			ps.setString(1, vo.getId());
			ps.setString(2, vo.getPassword());
			ps.setString(3, vo.getName());
			ps.setString(4, vo.getAddr());
			ps.executeUpdate();
		}finally {
			closeAll(ps, conn);
		}
	}

	@Override
	public ArrayList<Member> showAllMember() throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;	
		ResultSet rs = null;
		Member member = null;
		ArrayList<Member> memberList = new ArrayList<Member>();
		try {
			conn = getConnection();
			String query = "select id, password, name, address from member";
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				String id = rs.getString("id");
				String password = rs.getString("password");
				String name = rs.getString("name");
				String address = rs.getString("address");
				member = new Member(id, password, name, address);
				memberList.add(member);
			}

		}finally {
			closeAll(rs, ps, conn);
		}
		return memberList;
	}

	@Override
	public Member findMemberById(String tempId) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;	
		ResultSet rs = null;
		Member member = null;
		try {
			conn = getConnection();
			String query = "select id, password, name, address from member where id=?";
			ps = conn.prepareStatement(query);
			ps.setString(1, tempId);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				String id = rs.getString("id");
				String password = rs.getString("password");
				String name = rs.getString("name");
				String address = rs.getString("address");
				member = new Member(id, password, name, address);
			}
		}finally {
			closeAll(rs, ps, conn);
		}
		return member;
	}
	@Override
	public void updateMember(Member vo) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn= getConnection();
			String query = "update member set password=?, name=?, address=? where id = ?";
			ps = conn.prepareStatement(query);
			ps.setString(1, vo.getPassword());
			ps.setString(2, vo.getName());
			ps.setString(3, vo.getAddr());
			ps.setString(4, vo.getId());
			ps.executeUpdate();
		}
		finally {
			closeAll(ps, conn);
		}
		return;
	}
	
	public Member login(String tempId, String tempPassword)throws SQLException{
		Connection conn = null;
		PreparedStatement ps = null;	
		ResultSet rs = null;
		Member member = null;
		
		try {
			conn = getConnection();
			String query = "select id, password, name, address from member where id=? and password=?";
			ps = conn.prepareStatement(query);
			ps.setString(1, tempId);
			ps.setString(2, tempPassword);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				String name = rs.getString("name");
				String address = rs.getString("address");
				member = new Member(tempId, tempPassword, name, address);
			}
		}finally {
			closeAll(rs, ps, conn);
		}
		
		return member;
		
	}
	public static void main(String[] args) throws SQLException {
/*		MemberDAO dao = MemberDAOImpl.getInstance();
		dao.registerMember(new Member("id0r2", "123ㅇ4", "Lee", "Seoul"));*/
	}

}
