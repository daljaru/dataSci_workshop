package servlet.function;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import servlet.controller.ModelAndView;
import servlet.model.Member;
import servlet.model.MemberDAO;
import servlet.model.MemberDAOImpl;

public class RegisterController implements Controller {
	@Override
	public ModelAndView handle(HttpServletRequest request,  HttpServletResponse response) throws ServletException, IOException{
		String id = request.getParameter("userId");
		String password = request.getParameter("userPassword1");
		String name = request.getParameter("userName");
		String addr = request.getParameter("userAddress");
		
		try {
			MemberDAO dao = MemberDAOImpl.getInstance();
			Member member = new Member(id, password, name, addr);
			dao.registerMember(member); 
		} catch (SQLException e) {
			System.out.println("등록실패");
			return null;
		}
		request.setAttribute("id", id);
		request.setAttribute("name", name);
		return new ModelAndView("registerSuccess.jsp", true);
	}
}
