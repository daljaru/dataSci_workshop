package servlet.function;

public class HandlerMapping {
	
	private static HandlerMapping handler = new HandlerMapping();   
	//controllerfactory라고 했으면 controller를 생성하는 의미밖에 없었을 텐데  handlermapping이라고 해서 들어오는 값에 따라 매핑한다는 의미도 담고 있어서 매우 의미있는 네이미이다. 
	private HandlerMapping() {};
	
	public static HandlerMapping getInstance() {
		return handler;
	}
	
	public Controller createController(String command) {
		if(command.equals("allusers")) {
			return new AllUsersController();
		}else if (command.equals("edituser")) {
			return new EditUserController();
		}else if (command.equals("login")) {
			return new LoginController();
		}else if (command.equals("register")) {
			return new RegisterController();
		}else if (command.equals("findMember")) {
			return new FindMemberController();
		}else if (command.equals("logout")) {
			return new LogoutController();
		}
		return null;
	}
}
