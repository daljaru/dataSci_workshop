package servlet.function;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import servlet.controller.ModelAndView;
import servlet.model.Member;
import servlet.model.MemberDAOImpl;

public class FindMemberController implements Controller {
	@Override
	public ModelAndView handle(HttpServletRequest request,  HttpServletResponse response) throws ServletException, IOException {
		String userId = request.getParameter("userId");
		
		Member member = null;
		
		try {
			member = MemberDAOImpl.getInstance().findMemberById(userId);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		if(member == null) {
			return new ModelAndView("find_fail.jsp");
		}
		else {
			request.setAttribute("member", member);
			return new ModelAndView("find_ok.jsp");
		}
	}
}
