package servlet.function;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import servlet.controller.ModelAndView;
import servlet.model.Member;
import servlet.model.MemberDAOImpl;

public class LoginController implements Controller {
	@Override
	public ModelAndView handle(HttpServletRequest request,  HttpServletResponse response) throws ServletException, IOException {
		String userId = request.getParameter("userId");
		String userPassword = request.getParameter("userPassword");
		String sessionId = "";
		
		Member member = null;
		try {
			member = MemberDAOImpl.getInstance().login(userId, userPassword);
		} catch (SQLException e) {
			System.out.println("로그인 실패");
			return null;
		}
		
		HttpSession session = request.getSession();
		sessionId = session.getId();
		
		session.setAttribute("sessionId", sessionId);
		session.setAttribute("member", member);
		
		return new ModelAndView("loginResult.jsp");
	}
}
