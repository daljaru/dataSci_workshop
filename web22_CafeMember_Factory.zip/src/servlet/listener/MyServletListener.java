package servlet.listener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class MyServletListener implements ServletContextListener{
	private ServletContext sc;
	//dd읽고 servletContext생성 - ServletContextEvent발생 - 감지하자마자 호출.   : 가장 최초로 호출되는 메소드
	//컨테이너 차원의 초기하  로직은 여시서 ㅈㅈㄱ성..ㅇ
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		sc = sce.getServletContext();
		
		String filePath = sc.getInitParameter("vipFile");
		InputStream is = null;
		BufferedReader br = null;
		try {
			is = sc.getResourceAsStream(filePath);
			br = new BufferedReader(new InputStreamReader(is));
			String line = null;
			while((line=br.readLine())!=null) {
				System.out.println(line);
			}
		}catch(IOException e) {
			
		}
	}
	
	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		
	}

	

}
